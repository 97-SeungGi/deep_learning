from utils.Preprocess import Preprocess
from models.intent.IntentModel import IntentModel

p = Preprocess(word2index_dic='../../train_tools/dict/chatbot_dict.bin',
               userdic='../../utils/user_dic.tsv')

intent = IntentModel(model_name = '../models/intent/intent_model.h5',preprocess = p)

intent_labels = {0:"인사", 1:"욕설",2:"주문",3:"예약",4:"기타"}
query = ["오늘 탕수육 주문 가능한가요?","안녕하세요?"]
predict = intent.predict_class(query)

predict_label = intent.labels[predict]

print('label of class : {0} - {1}'.format(predict, predict_label))