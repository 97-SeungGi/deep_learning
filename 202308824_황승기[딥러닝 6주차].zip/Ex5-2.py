from konlpy.tag import Komoran
import numpy as np
from numpy import dot
from numpy.linalg import norm
komoran = Komoran()

#코사인 유사도
def cos_sim(vec1, vec2):
    return dot(vec1, vec2)/(norm(vec1)*norm(vec2)) 

#TDM
def make_term_doc_mat(sentence_bow, word_dics): #"6월","뉴턴"
    freq_mat = {}

    for word in word_dics:
        freq_mat[word] = 0

    for word in word_dics:
        if word in sentence_bow:
            freq_mat[word] += 1

    return freq_mat

def make_vector(tdm):   #"6월" ->0, "뉴턴" ->1
    vec = []
    for key in tdm:
        vec.append(tdm[key])
    return vec

s1 = ["a","b","c","d","e","f"]
s2 = ["a","b","c"]
dics = ["a","b","c","d","e","f"]

f1 = make_term_doc_mat(s1, dics)
print(f1)
f2 = make_term_doc_mat(s2, dics)
print(f2)

t1 = np.array(make_vector(f1))
print(t1)
t2 = np.array(make_vector(f2))
print(t2)
print(cos_sim(t1,t2))

sentence1 = '6월에 뉴턴은 선생님의 제안으로 트리니티에 입학하였다.'
sentence2 = '6월에 뉴턴은 선생님의 제안으로 대학교에 입학하였다.'
sentence3 = '나는 맛잇는 밥을 뉴턴 선생님과 함께 먹었습니다'

#형태소 분석기 명사묶음 추출
bow1 = komoran.nouns(sentence1)
bow2 = komoran.nouns(sentence2)
bow3 = komoran.nouns(sentence3)

#전체문장을 분석할수있는 단어사전을 만들어야하는게 코사인유사도의 단점. 
#하나의 사전을 만들어줘야함

bow = bow1 + bow2 + bow3

word_dics = []
for token in bow:
    if token not in word_dics:
        word_dics.append(token)

freq_list1 = make_term_doc_mat(bow1, word_dics)
freq_list2 = make_term_doc_mat(bow2, word_dics)
freq_list3 = make_term_doc_mat(bow3, word_dics)
print(freq_list1)
print(freq_list2)
print(freq_list3)

doc1 = np.array(make_vector(freq_list1))
doc2 = np.array(make_vector(freq_list2))
doc3 = np.array(make_vector(freq_list3))

r1 = cos_sim(doc1, doc2)
r2 = cos_sim(doc1, doc3)
r3 = cos_sim(doc2, doc3)
print(r1, r2, r3)

