from konlpy.tag import Komoran



komoran = Komoran()
#워드단위
def word_ngram(bow, num_gram):
    text = tuple(bow)
    ngrams = [text[x:x+num_gram] for x in range(0, len(text))]
    return tuple(ngrams)

#음절단위
def phoneme_ngram(bow, num_gram):
    sentence = ''.join(bow)
    text = tuple(sentence)
    ngrams = [text[x:x+num_gram] for x in range(0, len(text))]
    return tuple(ngrams)


test = "ABCDefghijklmn"
result = word_ngram(test,2)
print(result)


test2 = ["aa","bc","cd","df","fg"]
result2 = word_ngram(test2,2)
print(result2)

result3 = phoneme_ngram(test2,2)
print(result3)


#유사도 계산
def similarity(doc1, doc2):
    cnt = 0
    for token in doc1:
        if token in doc2:
            cnt = cnt + 1
    return cnt / len(doc1)

sentence1 = '6월에 뉴턴은 선생님의 제안으로 트리니티에 입학하였다.'
sentence2 = '6월에 뉴턴은 선생님의 제안으로 대학교에 입학하였다.'
sentence3 = '나는 맛잇는 밥을 뉴턴 선생님과 함께 먹었습니다'

#명사 형태소 추출
bow1 = komoran.nouns(sentence1)
bow2 = komoran.nouns(sentence2)
bow3 = komoran.nouns(sentence3)

print(bow3)

#어절단위 ngram
doc1 = word_ngram(bow1,2)
doc2 = word_ngram(bow2,2)
doc3 = word_ngram(bow3,2)
print(doc1)
print(doc2)
print(doc3)

#추출된 토큰으로 유사도함수 가지고 계산
s1 = similarity(doc1, doc2)
s2 = similarity(doc1, doc3)
s3 = similarity(doc2, doc3)
print(s1,s2,s3)


#형태소 추출한다음에 트라이그램
tri1 = word_ngram(bow1,3)
tri2 = word_ngram(bow2,3)
print(tri1)
print(tri2)
s4 = similarity(tri1, tri2)
print(s4)