from utils.Preprocess import Preprocess
from models.ner.NerModel import NerModel
import os

this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)


p = Preprocess(word2index_dic='C:/ChatbotLec/Chatbot/train_tools/dict/chatbot_dict.bin',
               userdic='../../utils/user_dic.tsv')

ner = NerModel (model_name = 'C:/ChatbotLec/Chatbot/models/ner/ner_model.h5', proprocess=p)
query = '오늘 오전 11시 30분에 탕수육을 주문하고 싶어요.'
predicts = ner.predict(query)
tags = ner.predict_tags(query)

print(query)
print("의도 예측 클래스 : ", predicts)
print("의도 예측 레이블 : ", tags)
