import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Flatten, Dense
from tensorflow.keras.datasets import mnist
import matplotlib.pyplot as plt
import numpy as np
import random
import os

# CUDA 비활성화 (선택 사항)
this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)
os.environ["CUDA_VISIBLE_DEVICES"] = "-1" #CUDA disable


# 데이터 로드 및 전처리
(x_train, y_train), (x_test, y_test) = mnist.load_data()
x_train, x_test = x_train / 255.0, x_test / 255.0
ds = tf.data.Dataset.from_tensor_slices((x_train, y_train)).shuffle(10000)

# 첫 번째 분할 비율 (6:4)
train_size_1 = int(len(x_train) * 0.6)
ds_1 = ds.take(train_size_1).batch(20)
train_ds_1 = ds.batch(20)
val_ds_1 = ds.skip(train_size_1).batch(20)

# 두 번째 분할 비율 (8:2)
train_size_2 = int(len(x_train) * 0.8)
ds_2 = ds.take(train_size_2).batch(20)
train_ds_2 = ds.batch(20)
val_ds_2 = ds.skip(train_size_2).batch(20)

# 첫 번째 모델 (6:4 분할)
model_1 = Sequential()
model_1.add(Flatten(input_shape=(28, 28)))
model_1.add(Dense(20, activation='relu'))
model_1.add(Dense(20, activation='relu'))
model_1.add(Dense(10, activation='softmax'))

model_1.compile(loss="sparse_categorical_crossentropy", optimizer="sgd", metrics=["accuracy"])
hist1 = model_1.fit(train_ds_1, validation_data=val_ds_1, epochs=10)



# 두 번째 모델 (8:2 분할)
model_2 = Sequential()
model_2.add(Flatten(input_shape=(28, 28)))
model_2.add(Dense(20, activation='relu'))
model_2.add(Dense(20, activation='relu'))
model_2.add(Dense(10, activation='softmax'))

model_2.compile(loss='sparse_categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])
hist2 = model_2.fit(train_ds_2, validation_data=val_ds_2, epochs=10)

# 첫 번째 모델 평가 (6:4 분할)
print('=' * 30)
print('모델 평가: 테스트 세트 (6:4 분할)')
model_1.evaluate(x_test, y_test)

# 두 번째 모델 평가 (8:2 분할)
print('=' * 30)
print('모델 평가: 테스트 세트 (8:2 분할)')
model_2.evaluate(x_test, y_test)

# 첫 번째 모델 요약 (6:4 분할)
print('=' * 30)
print('모델 요약 (6:4 분할)')
model_1.summary()

# 두 번째 모델 요약 (8:2 분할)
print('=' * 30)
print('모델 요약 (8:2 분할)')
model_2.summary()

#모델 저장
model_1.save('mnist_model6_4.h5')
model_2.save('mnist_model8_2.h5')



# 8:2는 더많은 학습 데이터를 사용하기 때문에 일반화 성능이 더 좋을수 있다.
# 6:4 모델은 더 작은 학습 데이터로 훈련되어 일부 경우에는 과적합을 줄이는효과가 있을수 있다.

# 3.
_, (x_test, y_test) = mnist.load_data()
x_test = x_test / 255.0

random_picks = random.sample(range(len(x_test)), 10)

model1 = load_model('mnist_model6_4.h5')
model1.evaluate(x_test, y_test, verbose=2)

model2 = load_model('mnist_model8_2.h5')
model2.evaluate(x_test, y_test, verbose=2)

predict1 = model1.predict(x_test[random_picks]).argmax(axis=-1)
predict2 = model2.predict(x_test[random_picks]).argmax(axis=-1)

print("model6_4 손글씨 이미지 예측값 : ", predict1)
print("model8_2 손글씨 이미지 예측값 : ", predict2)

fig = plt.figure()
i = 0

for pick in random_picks:
    subplot = fig.add_subplot(2, 5, i + 1)

    subplot.set_xticks([])
    subplot.set_yticks([])

    subplot.set_title('%d' % y_test[pick])
    subplot.imshow(x_test[pick], cmap='gray')
    i += 1

plt.show()