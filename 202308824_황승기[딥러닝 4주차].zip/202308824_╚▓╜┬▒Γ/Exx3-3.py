from konlpy.tag import Okt

okt = Okt()
text = "아버지가 방에 들어갑니다."
morphs = okt.morphs(text)
print(morphs)

pos = okt.pos(text)
print(pos)

#명사만 추출
nouns = okt.nouns(text)
print(nouns)

text2 = "오늘 날씨가 좋아욬ㅋㅋ"
print(okt.normalize(text2))
print(okt.phrases(text2))
