
# Kkma
from konlpy.tag import Kkma
#형태소 분류
kkma = Kkma()
text = "아버지가 방에 들어갑니다."

morphs = kkma.morphs(text)
print(morphs)

#품사까지 추출
pos = kkma.pos(text)
print(pos)

#명사만 추출
nouns = kkma.nouns(text)
print(nouns)

sentences = "오늘 날씨는 어때요? 내일은 덥다던데."
#문장을 자르기
s = kkma.sentences(sentences)
print(s)

#형태소추출 