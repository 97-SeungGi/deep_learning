from  konlpy.tag import Kkma, Komoran, Okt

kkma = Kkma()
komoran = Komoran()
okt = Okt()

text1 = "대한민국은 민주공화국이다."
text2 = "대한민국의 주권은 국민에게 있고, 모든 권력은 국민으로부터 나온다."

#형태소 분류
#kkma
morphs1 = kkma.morphs(text1)
morphs2 = kkma.morphs(text2)

print("kkma : ", morphs1)
print("kkma : ", morphs2)

#komoran
morphs3 = komoran.morphs(text1)
morphs4 = komoran.morphs(text2)

print()
print("komoran : ", morphs3)
print("komoran : ", morphs4)

#okt
morphs5 = okt.morphs(text1)
morphs6 = okt.morphs(text2)

print()
print("okt : ", morphs5)
print("okt : ", morphs6)


#명사만 추출
#kkma
nouns1 = kkma.nouns(text1)
nouns2 = kkma.nouns(text2)

print()
print("kkma:",nouns1)
print("kkma:",nouns1)

#komoran
nouns3 = komoran.nouns(text1)
nouns4 = komoran.nouns(text2)

print()
print("komoran:",nouns3)
print("komoran:",nouns4)

#okt
nouns5 = okt.nouns(text1)
nouns6 = okt.nouns(text2)

print()
print("okt:", nouns5)
print("okt:", nouns6)

#명사의 수
print("Kkma 명사의 수: ", len(nouns1))
print("Kkma 명사의 수: ", len(nouns2))

print("Komoran 명사의 수: ", len(nouns3))
print("komoran 명사의 수: ", len(nouns4))

print("okt 명사의 수: ", len(nouns5))
print("okt 명사의 수: ", len(nouns6))


# 각 명사의 사용 횟수 계산 함수
def count_nouns(nouns):
    noun_counts = {}
    for noun in nouns:
        if noun in noun_counts:
            noun_counts[noun] += 1
        else:
            noun_counts[noun] = 1
    return noun_counts

print()
print("kkma 각 명사 사용 횟수: ", count_nouns(nouns1))
print("kkma 각 명사 사용 횟수: ", count_nouns(nouns2))

print()
print("komoran 각 명사 사용 횟수: ", count_nouns(nouns3))
print("komoran 각 명사 사용 횟수: ", count_nouns(nouns4))

print()
print("okt 각 명사 사용 횟수: ", count_nouns(nouns5))
print("okt 각 명사 사용 횟수: ", count_nouns(nouns6))