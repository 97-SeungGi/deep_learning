from konlpy.tag import Komoran
import os

this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)

komoran = Komoran(userdic = "./user_dic.tsv")
text = "우리 챗봇은 엔엘피를 싫어해."

#명사추출
pos = komoran.pos(text)
print(pos)

