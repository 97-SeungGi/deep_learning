from gensim.models import Word2Vec
import os

this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)

model = Word2Vec.load('./nvmc.model')
print("corpus_total_words : {0}".format(model.corpus_total_words))

print('사랑 : {0}'.format(model.wv['사랑']))
print('결혼 : {0}'.format(model.wv['결혼']))

#두개사이의 유사도는??
print('사랑 == 결혼 : {0}'.format(model.wv.similarity(w1 = '사랑', w2 = '결혼') ))
print('사랑 == 여자친구 : {0}'.format(model.wv.similarity(w1 = '사랑', w2 = '여자친구') ))
print('영화 == 일요일 : {0}'.format(model.wv.similarity(w1 = '영화', w2 = '일요일') ))


print('일요일 == 월요일 : {0}'.format(model.wv.similarity(w1 = '일요일', w2 = '월요일') ))
print('안성기 == 배우 : {0}'.format(model.wv.similarity(w1 = '안성기', w2 = '배우') ))
print('대기업 == 삼성 : {0}'.format(model.wv.similarity(w1 = '대기업', w2 = '삼성') ))
print('일요일 == 삼성 : {0}'.format(model.wv.similarity(w1 = '일요일', w2 = '삼성') ))
print('히어로 == 삼성 : {0}'.format(model.wv.similarity(w1 = '히어로', w2 = '삼성') ))


print('사랑 == 죽음 : {0}'.format(model.wv.similarity(w1 = '사랑', w2 = '죽음') ))
print('사랑 == 원수 : {0}'.format(model.wv.similarity(w1 = '사랑', w2 = '원수') ))

#유사도 높은거 추출?? 5 = 5개추출, 10 = 10개추출
print(model.wv.most_similar('안성기', topn = 5))
print(model.wv.most_similar('일요일', topn = 10))



#과제 
#한국 nlp 한국 법률 말뭉치 코드