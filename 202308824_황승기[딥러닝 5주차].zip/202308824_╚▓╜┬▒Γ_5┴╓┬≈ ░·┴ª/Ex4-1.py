from konlpy.tag import Komoran
import numpy as np


komoran = Komoran()

text = "오늘 날씨는 구름이 많은 날씨에요."

#명사만 추출
nouns = komoran.nouns(text)
print(text)
print(nouns)

#단어사전 만들기(인덱스 부여)
dics = {}
#cnt = 0
for word in nouns:
    if word not in dics.keys():
 #       cnt = cnt+1
        dics[word] = len(dics)
print(dics)

a = np.eye(3)
print(a,"\n")


nb_classes = len(dics)
target = list(dics.values())
one_hot_targets = np.eye(nb_classes)[target]
print(one_hot_targets)

indata = input()
if indata in list(dics.keys()):
    print("{0} word's code : {1}".format(indata, one_hot_targets[dics[indata]]))


    