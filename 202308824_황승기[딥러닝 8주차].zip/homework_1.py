import tensorflow as tf
from tensorflow.keras import preprocessing
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Embedding, Dense, Dropout, Conv1D,GlobalMaxPool1D, concatenate
import pandas as pd
import os


this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)



# 저장된 감정 분류 CNN 모델 불러오기
model = load_model('cnn_model.h5')
model.summary()
print()

# 사용자 입력 10개 받아서 감정 예측 후 사랑(긍정)인 문장만 배열에 저장
texts = []
for i in range(10):
    sentence = str(input(f'문장을 입력하세요 ({i+1} / 10) :'))
    texts.append(sentence)

# 단어 인덱스 시퀀스 벡터
corpus = [preprocessing.text.text_to_word_sequence(text) for text in texts]
tokenizer = preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(corpus)
sequences = tokenizer.texts_to_sequences(corpus)

# 최대 패딩 사이즈
MAX_SEQ_LEN = 15 # 단어 시퀀스 벡터 크기
padded_seqs = preprocessing.sequence.pad_sequences(sequences,maxlen=MAX_SEQ_LEN, padding='post')

love_texts = [] # 사랑(긍정)인 문장들을 넣을 배열
for i, text in enumerate(texts):
    prediction = model.predict(padded_seqs[i:i+1])
    predicted_class = tf.math.argmax(prediction, axis=1).numpy()
    print(f'점수 예측 : {prediction}')
    print(f'클래스 예측 : {predicted_class}')
    if predicted_class == 2: # 사랑(긍정)일 경우 배열에 추가
        love_texts.append(text)

print('사랑(긍정)인 문장 : ')
for text in love_texts: # 사랑(긍정)인 문장들 출력
    print(text)

# chatbot_data.csv 파일에서 일상다반사로 분류된 문장만 추출하여 chatbot_normal.csv 파일로 저장
data = pd.read_csv('./chatbot_data.csv', delimiter=',')
df = data[data['label'] == 0]
df.to_csv('./chatbot_normal.csv', index=False)