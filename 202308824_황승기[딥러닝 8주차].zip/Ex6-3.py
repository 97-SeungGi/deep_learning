import tensorflow as tf
from tensorflow.keras import preprocessing
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, Dense, Dropout, Conv1D,GlobalMaxPool1D, concatenate
import pandas as pd
import os

this_program_directory = os.path.dirname(os.path.abspath(__file__))
os.chdir(this_program_directory)
os.environ["CUDA_VISIBLE_DEVICES"] = "-1" #CUDA disable

train_file = "./chatbot_data.csv"
data = pd.read_csv(train_file, delimiter=',')
features = data['Q'].tolist() #입력
labels = data['label'].tolist() #출력

print(features[0:5],'\n')
print(labels[0:5],'\n')

#임베딩 하기
#형태소 명사추출
corpus = [preprocessing.text.text_to_word_sequence(text) for text in features]
print(corpus[0:5],'\n')
#토큰화 하기
tokenizer = preprocessing.text.Tokenizer()
tokenizer.fit_on_texts(corpus)

#시퀸스값
sequences = tokenizer.texts_to_sequences(corpus)

#각 글자의 인덱스값 출력
word_index = tokenizer.word_index
print(sequences[0:5],'\n')

#몇개의 데이터를 쓸지?
MAX_SEQ_LEN = 15 # 단어 시퀀스 벡터 크기

padded_seqs = preprocessing.sequence.pad_sequences(sequences,maxlen=MAX_SEQ_LEN, padding='post')
print(padded_seqs[0:5])

# 학습용, 검증용, 테스트용 데이터셋 생성
ds = tf.data.Dataset.from_tensor_slices((padded_seqs, labels))
ds = ds.shuffle(len(features))

#학습셋:검증셋:테스트셋 = 7:2:1
train_size = int(len(padded_seqs) * 0.7)
val_size = int(len(padded_seqs) * 0.2)
test_size = int(len(padded_seqs) * 0.1)

#트레이닝 데이터셋 가져오기
train_ds = ds.take(train_size).batch(20)
val_ds = ds.skip(train_size).take(val_size).batch(20)
test_ds = ds.skip(train_size + val_size).take(test_size).batch(20)

# 하이퍼파라미터 설정
dropout_prob = 0.5
EMB_SIZE = 128
EPOCH = 5
VOCAB_SIZE = len(word_index) + 1 # 전체 단어 수

# CNN 모델 정의
#입력레이어 정의
input_layer = Input(shape=(MAX_SEQ_LEN))
embedding_layer = Embedding(VOCAB_SIZE, EMB_SIZE, input_length=MAX_SEQ_LEN)(input_layer)
dropout_emb = Dropout(rate=dropout_prob)(embedding_layer)

#필터 3개
conv1 = Conv1D(filters=128, kernel_size=3, padding='valid',activation=tf.nn.relu)(dropout_emb)
pool1 = GlobalMaxPool1D()(conv1)

conv2 = Conv1D(filters=128, kernel_size=4, padding='valid',activation=tf.nn.relu)(dropout_emb)
pool2 = GlobalMaxPool1D()(conv2)

conv3 = Conv1D(filters=128, kernel_size=5, padding='valid',activation=tf.nn.relu)(dropout_emb)
pool3 = GlobalMaxPool1D()(conv3)

#필터 3, 4, 5- gram 이후 합치기
concat = concatenate([pool1, pool2, pool3])


#클래스 구분
hidden = Dense(128, activation=tf.nn.relu)(concat)
dropout_hidden = Dropout(rate=dropout_prob)(hidden)
logits = Dense(3, name='logits')(dropout_hidden)
predictions = Dense(3, activation=tf.nn.softmax)(logits)

# 모델 생성
model = Model(inputs=input_layer, outputs=predictions)
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

print()
model.summary()

# 모델 학습
model.fit(train_ds, validation_data=val_ds, epochs=EPOCH, verbose=1)

# 모델 평가(테스트 데이터셋 이용)
loss, accuracy = model.evaluate(test_ds, verbose=1)
print('Accuracy: %f' % (accuracy * 100))
print('loss: %f' % (loss))
# 모델 저장
model.save('cnn_model.h5')