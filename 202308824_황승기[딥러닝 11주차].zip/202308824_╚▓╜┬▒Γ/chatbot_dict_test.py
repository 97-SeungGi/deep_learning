
# 챗봇에서 사용하는 사전 파일 생성
from utils.Preprocess import Preprocess
from tensorflow.keras import preprocessing
import pickle

f = open('./train_tools_dict/chatbot_dict.bin', 'rb')
word_index = pickle.load(f)
f.close()
sent = '내일 오전 10시에 탕수육 주문하고 싶어 ㅋㅋ'

p = Preprocess(userdic = './utils/user_dic.tsv')
pos = p.pos(sent)

keywords = p,get_keywords(pos, without_tag = True)
for word in keywords:
    try:
        print('{0} : {1}'.format(word, word_index[word]))
    except KeyError:
        # 해당 단어가 사전에 없는 경우, OOV 처리
        print(word, word_index['OOV'])
